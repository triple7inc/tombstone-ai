﻿namespace TombstoneAI.Library
{
    public static class DNID
    {
        public static int OPEN_BANK=-1831939431;
        public static int QUICK_HEAL=-391898789;
    }
}